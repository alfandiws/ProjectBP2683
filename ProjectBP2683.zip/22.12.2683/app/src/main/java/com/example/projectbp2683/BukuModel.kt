package com.example.projectbp2683

class BukuModel(var image:Int, var title:String, var desc:String) {
}