package com.example.projectbp2683

import android.icu.text.CaseMap.Title

class KunjPerp(var image:Int, var title: String, var desc:String){
}